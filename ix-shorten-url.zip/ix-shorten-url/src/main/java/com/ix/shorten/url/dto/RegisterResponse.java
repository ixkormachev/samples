package com.ix.shorten.url.dto;

public class RegisterResponse {
    private String shortUrl = "";

    public String getShortUrl() {
        return shortUrl;
    }

    public void setShortUrl(String shortUrl) {
        this.shortUrl = shortUrl;
    }

}

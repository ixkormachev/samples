INSERT INTO REDIRECTION(username, url, short_urL) VALUES ('accountid1', 'http://ya.ru', 'xYswlE');
INSERT INTO REDIRECTION(username, url, short_url) VALUES ('accountid2', 'http://ya.ru', 'xYswlE222222');
INSERT INTO REDIRECTION(username, url, short_url) VALUES ('accountid3', 'http://ya.ru', 'xYswlE333333');

